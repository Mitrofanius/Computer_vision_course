import torch
import numpy as np
import matplotlib.pyplot as plt

class Conv2D():
    def __init__(self, channels, kernel_size, stride=1, padding=None):
        ''' Parameters of Convolution
        channels: channels of input (binary image has 1, RGB something else)
        kernel_size: dimension of weights
        stride: jumping, use 1
        padding: adding zeros to borders of image, recompute for original image size '''
        # kernel_size = (10, 10)
        # kernel_size = (15, 15)
        # padding=7
        # stride=1
        # self.conv = torch.nn.Conv2d(
        #     in_channels=channels, out_channels=1, kernel_size=kernel_size, padding=padding, stride=stride, bias=False
        #     )
        kernel_size = (15, 15)
        stride=1
        padding=7
        self.conv = torch.nn.Conv2d(
            in_channels=channels, out_channels=1, kernel_size=kernel_size, padding=padding, stride=stride, bias=False
            )

    def set_weights(self, weights=None, bias=None):
        ''' For reassigning learned weights and bias for testing '''
        self.conv.weight = torch.nn.Parameter(weights.unsqueeze(0))
        # self.conv.bias = torch.nn.Parameter(0)
        

    def forward(self, x):
        ''' FeedForward pass'''
        x = self.conv(x)
        x = (-(torch.abs(torch.log(x)).detach()))
        # x = x.squeeze(0)
        x = x.squeeze(0)
        # return (x.squeeze(0) * 1).detach().numpy()
        return x

    def check_output_shape(self, *args):
        pass

if __name__ == '__main__':
    print("Evaluation script will perform followings steps ...")
    conv = Conv2D()

    stored_weights = torch.load('path_to_weights') # upload as well!!!
    # torch.save(weights, path) for storing the weights

    conv.set_weights(stored_weights)

    # output = conv.forward(x=x_test)    # x_test is different from provided image ...

    # Maximum of tensor "output" will be taken as a final position
    # You can reconstruct these step with data provided.
