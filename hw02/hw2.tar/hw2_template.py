import torch
import numpy as np
import matplotlib.pyplot as plt

class Conv2D():
    def __init__(self, channels, kernel_size, stride=1, padding=None):
        ''' Parameters of Convolution
        channels: channels of input (binary image has 1, RGB something else)
        kernel_size: dimension of weights
        stride: jumping, use 1
        padding: adding zeros to borders of image, recompute for original image size '''
        pass

    def set_weights(self, weights=None, bias=None):
        ''' For reassigning learned weights and bias for testing '''
        pass

    def forward(self, x):
        ''' FeedForward pass'''
        pass

    def check_output_shape(self, *args):
        pass

if __name__ == '__main__':
    print("Evaluation script will perform followings steps ...")
    conv = Conv2D()

    stored_weights = torch.load('path_to_weights') # upload as well!!!
    # torch.save(weights, path) for storing the weights

    conv.set_weights(stored_weights)

    output = conv.forward(x=x_test)    # x_test is different from provided image ...

    # Maximum of tensor "output" will be taken as a final position
    # You can reconstruct these step with data provided.
